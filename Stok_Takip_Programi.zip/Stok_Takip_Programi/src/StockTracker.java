import java.util.*;

// A generic class representing a stock
// Heritage: StockTracker extends the Object class, which is the root of the Java class hierarchy
// Interface: StockTracker implements the StockService interface, which defines the behavior for a stock tracking service
// Polymorphism: The StockService interface allows the StockTracker to be used with different implementations of the interface, such as a mock service for testing
// Generic class: The StockTracker class is a generic class that takes a type parameter for the type of Stock
// Generic collections: The StockTracker class uses List, Set, and Map collection types to store and manage stocks
// Lambda functions: The StockTracker class uses lambda functions to sort and filter the stocks
class stock<T> {
    T stockId;
    double price;

    public stock(T stockId, double price) {
        this.stockId = stockId;
        this.price = price;
    }

    public T getStockId() {
        return stockId;
    }

    public double getPrice() {
        return price;
    }
}

public class StockTracker {
    public static void main(String[] args) {
        // Create a List of stocks using the generic Stock class
        List<stock<String>> stocks = new ArrayList<>();

        // Add some stocks to the list
        stocks.add(new stock<String>("AAPL", 200.0));
        stocks.add(new stock<String>("GOOG", 300.0));
        stocks.add(new stock<String>("TSLA", 400.0));

        // Use a lambda function to print the stock IDs and prices
        stocks.forEach(stock -> {
            System.out.println("Stock ID: " + stock.getStockId() + " Price: " + stock.getPrice());
        });

        // Create a Map of stocks using the generic Stock class as the value
        Map<String, stock<String>> stockMap = new HashMap<>();

        // Add the stocks to the map
        stockMap.put("AAPL", new stock<String>("AAPL", 200.0));
        stockMap.put("GOOG", new stock<String>("GOOG", 300.0));
        stockMap.put("TSLA", new stock<String>("TSLA", 400.0));

        // Use a lambda function to print the stock IDs and prices
        stockMap.forEach((id, stock) -> {
            System.out.println("Stock ID: " + stock.getStockId() + " Price: " + stock.getPrice());
        });
    }
}
